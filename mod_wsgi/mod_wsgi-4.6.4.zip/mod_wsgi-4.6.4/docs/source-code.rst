===========
Source Code
===========

The source code repository for mod_wsgi is located on GitHub at:

* https://github.com/GrahamDumpleton/mod_wsgi

Downloadable tar balls of the source code can be found at:

* https://github.com/GrahamDumpleton/mod_wsgi/releases

A version of the source code which can be installed using ``pip`` can
also be found on PyPi at:

* https://pypi.python.org/pypi/mod_wsgi
