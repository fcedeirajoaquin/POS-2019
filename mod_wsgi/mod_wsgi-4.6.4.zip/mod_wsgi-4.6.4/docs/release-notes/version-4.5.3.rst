=============
Version 4.5.3
=============

Version 4.5.3 of mod_wsgi can be obtained from:

  https://codeload.github.com/GrahamDumpleton/mod_wsgi/tar.gz/4.5.3

Bugs Fixed
----------

1. Ensure that startup messages are flushed so immediately visible in logs.
